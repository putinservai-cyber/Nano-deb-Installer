import os
from nano_installer.crypto import simple_xor_decrypt, ENCRYPTION_KEY

# --- Configuration for AI Security Scanner ---
# Load API key from environment variable NANO_VT_API_KEY, falling back to a simple XOR-encrypted key.
ENCRYPTED_VT_API_KEY = "7a525b567f5d4342545f5e5d1163565144014c2e55415000572a075f09780c12120409585d136050551000127b57495307017c500c5b7c5c101051085b014137"
VT_API_KEY = os.environ.get("NANO_VT_API_KEY", simple_xor_decrypt(ENCRYPTED_VT_API_KEY, ENCRYPTION_KEY))